package com.example.angular.springbootangularawsfargate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAngularAwsFargateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAngularAwsFargateApplication.class, args);
	}

}
