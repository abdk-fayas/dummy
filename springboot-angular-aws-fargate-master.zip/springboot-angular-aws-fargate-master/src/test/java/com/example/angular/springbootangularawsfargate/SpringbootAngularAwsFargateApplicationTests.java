package com.example.angular.springbootangularawsfargate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAngularAwsFargateApplicationTests {

	@Test
	void contextLoads() {
	}

}
